package com.edubridge.looingstatement;

public class DoWhileDemo {

	public static void main(String[] args) {
		int a=22;
		do {
			System.out.println(a+" ");
			a++;
			
		}
		while(a<=22);

	}

}
