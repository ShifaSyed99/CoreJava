package com.edubridge.looingstatement;

import java.util.Scanner;

public class ForLoopDemo {

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		int N=s.nextInt();
		int i;
		for(i=1;i<=N;i++)
		{ 
			System.out.print(i+" ");
		}
	}
}


