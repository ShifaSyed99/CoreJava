package com.edubridge.selectionstatement;
import java.util.Scanner;
public class CascadedIfElseDemo {

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		int a=s.nextInt();
		int b=s.nextInt();
		int c=s.nextInt();
		if(a>b && a>c)
		{
			System.out.println("a is heavier");
		}
		else if(b>a && b>c)
		{
			System.out.println("b is heavier");
		}
		else 
			System.out.println("c is heavier");

	}

}
