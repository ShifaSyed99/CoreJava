package com.aop;

public class Swiggy {
	
	public void wecome() {
		System.out.println("Welcome to The Restaurant.");
	}

	
	public void vegMenu() {
		System.out.println("This method contains Vegetarian Cuisines.");
	}
	
	public void nonVegMenu() {
		System.out.println("This method contains Non Vegetarian Cuisines.");
	}
	
	public void starterMenu() {
		System.out.println("This method contains Snacks.");
	}


}
