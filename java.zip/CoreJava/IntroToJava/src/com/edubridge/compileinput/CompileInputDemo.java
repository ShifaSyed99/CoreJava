package com.edubridge.compileinput;
//demo on compile time input of data tpes
public class CompileInputDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		byte num1  = 127;
		short num2 = 3433;
		int num3 = 123456789;
		long num4 = 0123456701234l;
		float num5 = 53.6f;
		double num6 = 54.5d;
		char c = 'X';
		String str = "EduBridge";
		System.out.println(num1);
		System.out.println(num2);
		System.out.println(num3);
		System.out.println(num4);
		System.out.println(num5);
		System.out.println(num6);
		System.out.println(str);
		System.out.println(c);

	}

}
