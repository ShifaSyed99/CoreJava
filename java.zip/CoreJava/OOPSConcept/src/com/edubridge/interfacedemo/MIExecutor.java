package com.edubridge.interfacedemo;

public class MIExecutor {

	public static void main(String[] args) {
		
		Learner l = new Learner();
		System.out.println(l.delete(l));

	}

}
