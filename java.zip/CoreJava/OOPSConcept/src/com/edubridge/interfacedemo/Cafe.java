package com.edubridge.interfacedemo;

public interface Cafe {
//all fields in interface are by default abstarct public static final
	String menu = "Pav Bhaji";
	int price = 60;
	
	////all fields in interface are by default public abstarct

	void showMenu();
	
	void displayPrice();
}
