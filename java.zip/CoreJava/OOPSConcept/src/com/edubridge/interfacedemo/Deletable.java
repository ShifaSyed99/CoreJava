package com.edubridge.interfacedemo;

//an interface that does not have methods and constants is marker interface(MI) which provides run time info about object

public interface Deletable {

}
