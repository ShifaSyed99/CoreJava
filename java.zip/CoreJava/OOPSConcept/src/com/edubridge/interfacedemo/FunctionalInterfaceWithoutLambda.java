package com.edubridge.interfacedemo;

public class FunctionalInterfaceWithoutLambda {

	public static void main(String[] args) {
		
		Fusion f = new Fusion();
		f.dispdetails();

	}

}
