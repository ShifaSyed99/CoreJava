package com.edubridge.interfacedemo;
//implementable class
public class Fusion implements Company {

	@Override
	public void dispdetails() {
		System.out.println(estb+" "+hq);
		
	}

}
