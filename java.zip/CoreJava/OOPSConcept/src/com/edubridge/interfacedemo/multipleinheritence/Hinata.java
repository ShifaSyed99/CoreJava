package com.edubridge.interfacedemo.multipleinheritence;
//Parent class 2
public interface Hinata {

	void powerTwo(int nochildren, String clan);
	
}
