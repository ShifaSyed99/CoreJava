package com.edubridge.interfacedemo.multipleinheritence;
//Parent class 1
public interface Naruto {
	
	void powerOne(int nochildren, String position);

}
