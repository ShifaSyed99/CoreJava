package com.edubridge.interfacedemo;

public class InterfaceExecutor {

	public static void main(String[] args) {
		// we cant create object for interface
		
		TheVibe t = new TheVibe();
		
		t.showMenu();
		t.displayPrice();
	}

}
