package com.edubridge.interfacedemo.methodreference.constructorreference;

@FunctionalInterface
public interface Edubridge {
	
	//reference to  a constructor
	Trainer getname(String name);

}
