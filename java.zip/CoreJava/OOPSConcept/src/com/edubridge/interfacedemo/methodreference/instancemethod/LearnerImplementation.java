package com.edubridge.interfacedemo.methodreference.instancemethod;


public class LearnerImplementation {
	
	public void learnMockito()
	{
		System.out.println("Mockito with JUnit 5.");
	}

	public static void main(String[] args) {
		//reference to instance method
		LearnerImplementation l1 = new LearnerImplementation();
		Learner l = l1::learnMockito;

		l.learn();
	}

}
