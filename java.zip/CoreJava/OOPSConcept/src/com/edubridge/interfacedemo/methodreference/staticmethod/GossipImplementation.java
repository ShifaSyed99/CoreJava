package com.edubridge.interfacedemo.methodreference.staticmethod;

////reference to static method
public class GossipImplementation {
	
	public static void classGossip()
	{
		System.out.println("Funtional Interface");
	}
	
	
	public static void main(String[] args) {
		//referring to the static method 
		Gossip g = GossipImplementation :: classGossip;
		g.talk();
	}
}
