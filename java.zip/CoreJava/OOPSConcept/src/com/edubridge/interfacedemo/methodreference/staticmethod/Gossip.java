package com.edubridge.interfacedemo.methodreference.staticmethod;

public interface Gossip {
	
	//abstract method
	void talk();

}
