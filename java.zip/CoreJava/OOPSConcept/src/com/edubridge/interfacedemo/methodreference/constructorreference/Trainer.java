package com.edubridge.interfacedemo.methodreference.constructorreference;

public class Trainer {
	
	//public String name;

	public Trainer(String name) {
		/*super();
		this.name = name;*/
		
		System.out.println("Trainer name : "+name);
	}

}
