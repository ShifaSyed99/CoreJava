package com.edubridge.interfacedemo.methodreference.instancemethod;

public interface Learner {
	
	void learn();

}
