package com.edubridge.interfacedemo.methodreference.constructorreference;

public class ConstructorReferenceDemo {

	public static void main(String[] args) {
		
		Edubridge e = Trainer:: new;
		e.getname("Shiwani");

	}

}
