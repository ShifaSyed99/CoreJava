package com.edubridge.interfacedemo;

@FunctionalInterface
public interface Company {
	
	String estb = "12th May 1998";
	String hq = "Mumbai";
	
	void dispdetails();
	//contains only one abstract method
	//void dispcomp();

}
