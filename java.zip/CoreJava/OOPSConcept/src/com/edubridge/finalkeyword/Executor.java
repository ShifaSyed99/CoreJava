package com.edubridge.finalkeyword;

public class Executor {

	public static void main(String[] args) {
		
		Passport p = new Passport();
		
		p.setcName("Passport");
		p.setDOExpiry("17/05/2026");
		System.out.println(p);
	}

}
