package com.edubridge.polymorphism;
//method overriding
//parent class
public class Google {

	String appn;
	String mail;
	
	public void accept(String appn, String mail)
	{
		
		System.out.println(appn+" "+mail);
	}
}
