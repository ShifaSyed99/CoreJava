package com.edubridge.abstractiondemo;

public class ISRO extends GovernmentAgency {

	@Override
	void disp() {
		// TODO Auto-generated method stub
		
	}

	@Override
	void disp(String agencyn, long budget) {
		// TODO Auto-generated method stub
		
	}

}
