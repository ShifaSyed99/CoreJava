/*Single inheritence*
 */
package com.edubridge.inheritence.single;

//Parent Class
public class Trainer {
	public String Trainername;
	public String Institutename;
	
	void display()
	{
		System.out.println(Trainername+" "+Institutename);
	}

}
