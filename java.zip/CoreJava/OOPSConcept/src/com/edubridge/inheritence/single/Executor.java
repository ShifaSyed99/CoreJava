package com.edubridge.inheritence.single;

public class Executor {

	public static void main(String[] args) {
		
		Learner l = new Learner();
		l.Institutename = "Edubridge";
		l.Trainername = "Shiwani";
		l.Learnername = "Shifa";
		l.Rollno = 1;
		l.display();
		

	}

}
