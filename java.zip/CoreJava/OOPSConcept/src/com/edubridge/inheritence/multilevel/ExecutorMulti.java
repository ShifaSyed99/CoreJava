package com.edubridge.inheritence.multilevel;

public class ExecutorMulti {
	
	public static void main(String args[])
	{
		Son s = new Son("Jerry", 20);
		System.out.println(s);
	}

}
