package com.edubridge.guestlec;

public class Student {

	String name = "John";
	
	int roll_no = 2;
	

	public static void main(String[] args) {

		Student s = new Student();
		
		System.out.println(s.name+""+s.name);

	}

}
