package com.edubridge.guestlec;

import java.util.Scanner;

public class GuestLecture {

	public static void main(String[] args) {
		
		Scanner s = new Scanner(System.in);
		//question on WA

	}

}
