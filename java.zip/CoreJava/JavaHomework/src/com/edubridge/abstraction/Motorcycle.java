package com.edubridge.abstraction;

public class Motorcycle extends Vehicle {
	
	void startEngine()
	{
		System.out.println("Motorcycle Engine started.");
	}
	
	void stopEngine()
	{
		System.out.println("Motorcycle Engine stopped.");
	}
}
