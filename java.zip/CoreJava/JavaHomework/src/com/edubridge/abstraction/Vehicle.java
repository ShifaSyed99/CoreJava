package com.edubridge.abstraction;

public abstract class Vehicle {
	
	abstract void startEngine();
	
	abstract void stopEngine(); 
	

}
