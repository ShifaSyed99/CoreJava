package com.edubridge.abstraction;

public class Car extends Vehicle {
	
	void startEngine()
	{
		System.out.println("Car Engine started.");
	}
	
	void stopEngine()
	{
		System.out.println("Car Engine stopped.");
	}

}
