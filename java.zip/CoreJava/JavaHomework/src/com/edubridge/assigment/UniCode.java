package com.edubridge.assigment;

import java.util.Scanner;

public class UniCode {

	public static void main(String[] args) {
		

		/*char char1 = 'G';
		int char11 = char1;
		System.out.println(char11);
		
		char char2 = 'B';
		int char22 = char2;
		System.out.println(char22);*/
		
		
		Scanner s = new Scanner(System.in);
		char a = s.next().charAt(0);
		System.out.print((int)a);
s.close();
	}

}
