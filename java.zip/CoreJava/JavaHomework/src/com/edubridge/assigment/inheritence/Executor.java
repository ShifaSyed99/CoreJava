package com.edubridge.assigment.inheritence;

public class Executor {

	public static void main(String[] args) {
		
		SavingAccount o = new SavingAccount(); 
		
		o.deposit(900);
		o.withdraw(9000, 200000);
		

	}

}
