package com.edubridge.assigment.inheritence;

public class SavingAccount extends BankAccount {
	{
		this.withdraw(9000, 200000);
	}

}
