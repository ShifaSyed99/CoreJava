package com.edubridge.uncheckedexception;

import java.util.Scanner;

public class ArithmeticExceptionNew {
	
	void even()
	{
		int n = 0;
	}
	
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		/*int a = s.nextInt();
		
		try
		{
			if(a % 2 == 0)
				System.out.println("The no is even:");
		}
		catch(Exception e)
		{
			System.out.println("Exception occurred");
		}
	s.close();
	}*/
}
}
