package com.edubridge.looingstatement;

public class LoopingStatementDemo {

	public static void main(String[] args) {
		char arr[]= {65,66,67};
		for (char i:arr)
		{
			System.out.println(i+" ");
		}

	}

}
