package com.edubrudge.interview;

import java.util.Scanner;

public class CodeTest {

	public static void main(String[] args) {
	
		Scanner s = new Scanner(System.in);
		
		System.out.println("Enter the no of values");
		int m = s.nextInt();
		
		System.out.println("Enter the no of values");
		int n = s.nextInt();
		
		int a[][] = new int[m][n];
		
		System.out.println("Enter array values:");
		
		for(int i=0 ; i<m; i++)
		{
			for(int j=0; j<n; j++)
			{
				a[i][j] = s.nextInt();
			}
		}
		for(int i=0 ; i<m; i++)
		{
			for(int j=0; j<n; j++)
			{
				System.out.print(a[i][j]+" ");
			}
			System.out.println();
		}
		s.close();
	}

}

