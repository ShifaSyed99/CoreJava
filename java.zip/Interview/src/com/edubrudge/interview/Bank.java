package com.edubrudge.interview;

public interface Bank {
	
	void getROI(double i);
	
	//return getROI;
	

}
