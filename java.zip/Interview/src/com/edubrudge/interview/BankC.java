package com.edubrudge.interview;

public class BankC implements Bank{

	@Override
	public void getROI(double i) {
		// TODO Auto-generated method stub
		
	}

}
