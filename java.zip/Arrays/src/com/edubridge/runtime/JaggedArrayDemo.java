package com.edubridge.runtime;

import java.util.Scanner;

public class JaggedArrayDemo {

	public static void main(String[] args) {
		
		Scanner s = new Scanner(System.in);
		//int n = s.nextInt();
		//declaration for outside jagged array 
		//int a[][] = new int [n][];
		
		System.out.println("Enter the values for member arrays");
		
		//Takes values from user
		//int x = s.nextInt();
		//int y = s.nextInt();
		
		
		 //a[i] = new int [x];
		// a[j] = new int [y];
		
		s.close();
		
		

	}

}
